from django.db import models

class Login(models.Model):
    Nombre = models.CharField(max_length=25)
    Pass = models.CharField(max_length=50)