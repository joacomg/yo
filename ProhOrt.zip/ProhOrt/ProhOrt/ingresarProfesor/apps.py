from django.apps import AppConfig


class IngresarprofesorConfig(AppConfig):
    name = 'ingresarProfesor'
